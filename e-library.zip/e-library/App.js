import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import BottomTabNavigator from './components/BottomTabNavigator';
import * as Font from 'expo-font';
import { Rajdhani_600SemiBold } from '@expo-google-fonts/rajdhani';

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      fontLoaded: false,
    };
  }

  async loadFonts() {
    await Font.loadAsync({ Rajdhani_600SemiBold: Rajdhani_600SemiBold });
    this.setState({ fontLoaded: true });
  }

  componentDidMount() {
    this.loadFonts();
  }
  render() {
    const { fontLoaded } = this.state;
    if (fontLoaded) {
      return <BottomTabNavigator />;
    }
    return null;
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
